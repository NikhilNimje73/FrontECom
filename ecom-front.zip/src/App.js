import React, { Fragment } from 'react';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import "react-datepicker/dist/react-datepicker.css"; 
import OurStore from './pages/OurStore';

function App() {
  return (
    <Fragment>
      <BrowserRouter>
        <Routes>
            <Route path='/' element={<Layout />}>
                <Route index element={<Home />} />
                <Route path='/about' element={<About />} />
                <Route path='/contact' element={<Contact />} />
                <Route path='/store' element={<OurStore />} />
            </Route>
        </Routes>
      </BrowserRouter>
    </Fragment>
  );
}

export default App;
