import React, { Fragment } from 'react'
import { Link } from 'react-router-dom'
import {BsLinkedin, BsGithub, BsYoutube, BsInstagram} from 'react-icons/bs';

const Footer = () => {
  return (
    <Fragment>
      <footer className='py-3'>
        <div className='container'>
          <div className='row align-items-center'>
            <div className='col-md-5'>
              <div className='footer-top-data d-flex gap-30 align-items-center'>
                <img src='images/newsletter.png' className='me-2' />
                <h4 className='mb-0 text-white'>Sign Up For Newsletter</h4>
              </div>
            </div>
            <div className='col-md-7'>
              <div className="input-group">
                <input type="text" className="form-control" id="basic-url" placeholder='Your Email Address' />
                <span className="input-group-text text-white p-2" id="basic-addon3">Subscribed</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <footer className='py-3'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-4'>
              <h5 className='text-white mb-3'>Contact Us</h5>
              <div>
                <address className='text-white fs-6'>
                  Hno:277, Near Ganeshpeth, <br />
                  Bus Stand , Nagpur<br />
                  Pin code:440018.
                </address>
                <a href='tel:+919975859858' className='mt-0 text-white d-block mb-2'>+919975859858</a>
                <a href='mailto:support@aswtech.in' className='mt-0 text-white d-block mb-3'>support@aswtech.in</a>
                <div className='social-icons d-flex align-items-center gap-20'>
                  <a href=''>
                   <BsLinkedin className='text-white fs-5' />
                  </a>
                  <a href=''>
                    <BsInstagram className='text-white fs-5' />
                  </a>
                  <a href=''>
                    <BsGithub className='text-white fs-5' />
                  </a>
                  <a href=''>
                    <BsYoutube className='text-white fs-5' />
                  </a>
                </div>
              </div>
            </div>
            <div className='col-md-3'>
              <h5 className='text-white mb-3'>Information</h5>
              <div className='footer-links d-flex flex-column'>
                <Link to="" className='text-white py-1 mb-1' >Privacy Policy</Link>
                <Link to="" className='text-white py-1 mb-1'>Refund Policy</Link>
                <Link to="" className='text-white py-1 mb-1'>Shipping Policy</Link>
                <Link to="" className='text-white py-1 mb-1'>Terms of Service</Link>
                <Link to="" className='text-white py-1 mb-1'>Blogs</Link>
              </div>
            </div>
            <div className='col-md-3'>
              <h5 className='text-white mb-3'>Account</h5>
              <div className='footer-links d-flex flex-column'>
                <Link to="" className='text-white py-1 mb-1' >Search</Link>
                <Link to="" className='text-white py-1 mb-1' >About Us</Link>
                <Link to="" className='text-white py-1 mb-1'>Faq</Link>
                <Link to="" className='text-white py-1 mb-1'>Contact</Link>
                <Link to="" className='text-white py-1 mb-1'>Site Chart</Link>
              </div>
            </div>
            <div className='col-md-2'>
              <h5 className='text-white mb-3'>Quick Links</h5>
              <div className='footer-links d-flex flex-column'>
                <Link to="" className='text-white py-1 mb-1' >Laptops</Link>
                <Link to="" className='text-white py-1 mb-1'>Headphones</Link>
                <Link to="" className='text-white py-1 mb-1'>Tablets</Link>
                <Link to="" className='text-white py-1 mb-1'>Watches</Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <footer className='py-3'>
        <div className="container">
          <div className="row">
            <div className='col-12'>
              <p className='mb-0 text-center text-white'>&copy; {new Date().getFullYear()} . Powered By Developer Corner.</p>
            </div>
          </div>
        </div>
      </footer>
    </Fragment>
  )
}

export default Footer
