import React, { Fragment } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { BsSearch } from 'react-icons/bs'

const Header = () => {
  return (
    <Fragment>
      <header className='header-top-strip'>
        <div className="container-xl">
          <div className="row">
            <div className='col-6'>
              <p>Free Shipping over $100 & Free Returns</p>
            </div>
            <div className='col-6'>
              <p className='text-end'>Hotline: <a href="tel:919986858585">+91-9859858985</a></p>
            </div>
          </div>
        </div>
      </header>
      <header className='header-upper py-3'>
        <div className="container-xl">
          <div className="row align-items-center">
            <div className='col-2'>
              <h4>
                <Link to="/" className='text-white'>DIGITIC</Link>
              </h4>
            </div>
            <div className='col-5'>
              <div className="input-group">
                <input type="text" className="form-control" id="basic-url" placeholder='Search product here' />
                <span className="input-group-text" id="basic-addon3"><BsSearch /></span>
              </div>
            </div>
            <div className='col-5'>
              <div className='header-upper-link d-flex justify-content-between align-align-items-center'>
                <div>
                  <Link to="" className='d-flex align-items-center gap-10 text-white'>
                    <img src="images/compare.svg" />
                    <p className='mb-0'>Compare <br /> Product</p>
                  </Link>
                </div>
                <div>
                  <Link to="" className='d-flex align-items-center gap-10 text-white'>
                    <img src="images/wishlist.svg" />
                    <p className='mb-0'>Favorite <br /> Wishlist</p>
                  </Link>
                </div>
                <div>
                  <Link to="" className='d-flex align-items-center gap-10 text-white'>
                    <img src="images/user.svg" />
                    <p className='mb-0'>Login <br /> My Account</p>
                  </Link>
                </div>
                <div>
                  <Link to="" className='d-flex align-items-center gap-10 text-white'>
                    <img src="images/cart.svg" />
                    <div className='d-flex flex-column'>
                      <span className='badge bg-white text-dark'>0</span>
                      <p className='mb-0'>$ 0.00</p>
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <header className='header-bottom py-3'>
        <div className='container-xl'>
          <div className='row'>
            <div className='col-12'>
              <div className='menu-bottom d-flex align-items-center gap-15'>
                <div>
                  <div class="dropdown ">
                    <button class="btn btn-secondary bg-transparent gap-15 text-dark dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src='images/menu.svg' className='filter me-2' /> 
                      <span className='me-3'>Shop Categories</span>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                      <li><Link class="dropdown-item" to="#">Action</Link></li>
                      <li><Link class="dropdown-item" to="#">Another action</Link></li>
                      <li><Link class="dropdown-item" to="#">Something else here</Link></li>
                    </ul>
                  </div>
                </div>
                <div className='menu-links'>
                  <div className='d-flex align-items-center gap-15'>
                    <NavLink className="text-dark" to="/">Home</NavLink>
                    <NavLink className="text-dark" to="/store">Our Store</NavLink>
                    <NavLink className="text-dark" to="/">Blogs</NavLink>
                    <NavLink className="text-dark" to="/contact">Contact</NavLink>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
    </Fragment>
  )
}

export default Header
