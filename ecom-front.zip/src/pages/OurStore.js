import React, { Fragment } from 'react'
import BreadCrum from '../components/BreadCrum'
import Meta from '../components/Meta'

const OurStore = () => {
    return (
        <Fragment>
            <Meta title={"Our Store"} />
            <BreadCrum title="Our Store" />
            <section className='store-wrapper section-wrapper-2 py-5'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-md-3'>
                            <div className='filter-card mb-3'>
                                <h3 className='filter-title'>Shop By Category</h3>
                            </div>
                            <div className='filter-card mb-3'>
                                <h3 className='filter-title'>Filter by</h3>
                            </div>
                            <div className='filter-card mb-3'>
                                <h3 className='filter-title'>Shop By Category</h3>
                            </div>
                            <div className='filter-card mb-3'>
                                <h3 className='filter-title'>Shop By Category</h3>
                            </div>
                        </div>
                        <div className='col-md-9'>

                        </div>
                    </div>
                </div>
            </section>
        </Fragment>
    )
}

export default OurStore
